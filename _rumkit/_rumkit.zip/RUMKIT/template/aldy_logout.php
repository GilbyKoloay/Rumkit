<?php
session_start();
session_destroy();
echo "<center><br><br><br>
	  Logout Berhasil<br>Have a nice day..!<br><br>
	  <a href='index.php'>Kembali Ke Menu </a></center>";
	  exit;


?>