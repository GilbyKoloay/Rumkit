<?php
echo "<center><img src='images/foto_pariwisata.jpg' width=800></center>"


?>